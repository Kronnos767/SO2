# Laboratório 01 — Sistemas Operacionais 2

Repositório com a resolução dos 10 exercícios da Lista 01, implementados em Python 3.

## Requisitos

- Python 3.10 ou superior
- Apenas biblioteca padrão do Python

## Arquivos

- `ex01_corrida_cavalos.py` — corrida com threads, aposta, barreira e exclusão mútua;
- `ex02_produtor_consumidor.py` — buffer circular com produtores/consumidores;
- `ex03_transferencias.py` — transferências seguras e comparação com condição de corrida;
- `ex04_pipeline.py` — pipeline captura/processamento/gravação;
- `ex05_thread_pool.py` — pool fixo de threads e fila concorrente;
- `ex06_map_reduce.py` — soma e histograma com 1, 2, 4 e 8 threads;
- `ex07_filosofos.py` — duas soluções para o problema dos filósofos;
- `ex08_backpressure.py` — bursts, ociosidade e backpressure;
- `ex09_revezamento.py` — sincronização com barreira;
- `ex10_deadlock_watchdog.py` — deadlock proposital, thread watchdog e correção;
- `gerar_dados.py` — gera o arquivo utilizado no exercício 6;
- `relatorio.md` — explicação das implementações, execuções e resultados;
- `resultados/` — saídas obtidas nos testes.

## Como executar

Abra um terminal na raiz do repositório.

```bash
python ex01_corrida_cavalos.py
python ex02_produtor_consumidor.py
python ex03_transferencias.py
python ex04_pipeline.py
python ex05_thread_pool.py --demo
python gerar_dados.py
python ex06_map_reduce.py
python ex07_filosofos.py
python ex08_backpressure.py
python ex09_revezamento.py
python ex10_deadlock_watchdog.py
```

### Exercício 5 pela entrada padrão

O exercício 5 foi implementado para receber tarefas até EOF.

Linux/macOS:

```bash
python ex05_thread_pool.py
```

Digite um inteiro por linha e finalize com `Ctrl+D`.

Windows:

```powershell
python ex05_thread_pool.py
```

Digite um inteiro por linha e finalize com `Ctrl+Z` seguido de `Enter`.


## Execução no Google Colab / Jupyter

Os programas também são compatíveis com Google Colab e Jupyter Notebook. Esses ambientes adicionam argumentos internos ao kernel (por exemplo, `-f ...kernel.json`). Por isso, os scripts usam `parse_known_args()` para ignorar somente argumentos externos que não pertencem à atividade.

Você pode enviar os arquivos `.py` para o Colab e executar, por exemplo:

```python
!python ex01_corrida_cavalos.py --aposta 2
```

Ou colar o código diretamente em uma célula e executá-lo.

## Relatório

A explicação completa de cada exercício e os resultados experimentais estão em [`relatorio.md`](relatorio.md).
